# Australian Imaging Service Pipelines Community Python Package

Python package to collect custom pipeline code (typically Pydra workflows) to implement
community contributed pipelines for the Australian Imaging Service.
